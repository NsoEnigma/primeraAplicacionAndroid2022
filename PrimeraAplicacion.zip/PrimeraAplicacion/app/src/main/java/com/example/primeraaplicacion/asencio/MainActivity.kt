package com.example.primeraaplicacion.asencio

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.util.Scanner

public class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.setContentView(R.layout.layout_formulario)
        var btPagar:Button = this.findViewById<Button>(R.id.botonPagar)
        Log.v("visibilidad pagar", ""+ btPagar.visibility);
        btPagar.visibility=View.VISIBLE;
        //Toast.makeText(this,""+this.getText(R.string.visibilidadPagar)+" "+btPagar.visibility,Toast.LENGTH_LONG).show()
        //var toast:Toast=Toast.makeText(this,"hola segundo toast",Toast.LENGTH_LONG)
        //toast.show()
        var campoCantidad:EditText = this.findViewById<EditText>(R.id.campoCantidad)
        var textoTotal:TextView = this.findViewById(R.id.total)
        var valorAcumulado:Float = 0f

        if (campoCantidad.text.isEmpty()) {

        }else{
            btPagar.setOnClickListener {
                Toast.makeText(this,""+this.getText(R.string.cantidadQuePagare)+""+campoCantidad.text,Toast.LENGTH_LONG).show()
                valorAcumulado += campoCantidad.text.toString().toFloat()
                textoTotal.text=""+valorAcumulado

                campoCantidad.setText("")

                if (campoCantidad.getText().toString().trim() < "1"){
                    textoTotal.setBackgroundColor(getResources().getColor(R.color.red))
                    textoTotal.text="eres una rata"
                }



            }
        }


    }

    public fun funcionDeprueba(arg1:String):Unit{

    }
}